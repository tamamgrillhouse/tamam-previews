// TAMAM Inspector — Network hook (MAIN world)
// Τρέχει στο context της σελίδας (document_start) ΠΡΙΝ φορτώσει ο κώδικας του e-food,
// ώστε να κάνει patch το fetch/XHR και να συλλάβει τα JSON responses του partner API.
// Στέλνει ό,τι πιάνει στο content.js (ISOLATED world) μέσω window.postMessage.
(function () {
  'use strict';
  const TAG = '__TAMAM_EFOOD_CAPTURE__';
  const MAX_BODY = 1_800_000; // ~1.8MB cap ανά response
  const MAX_ACT_BODY = 6_000; // αιτήματα ενέργειας είναι μικρά — cap request/response body

  // Endpoints διαθεσιμότητας/ενεργειών προϊόντος & ΥΛΙΚΩΝ (μη-διαθέσιμο σήμερα/αόριστον/μέχρι).
  // Στόχος: να συλλάβουμε το ΑΙΤΗΜΑ (method + body) όχι μόνο την απάντηση, ώστε να το
  // αναπαράγει αργότερα το extension (sold-out → e-food).
  // v2.5: διευρυμένο — πιάνει ΚΑΘΕ μη-GET write στα catalogs/products/availability.
  // v2.6: (α) TRACK_RE αποκλείει telemetry/analytics (Google Analytics /g/collect κ.λπ. — έμπαιναν
  //       σαν actions επειδή το tracking URL περιέχει «availability» στο query string).
  //       (β) πιάνει ΚΑΙ options/ingredient availability: `product-options` REST + GraphQL `/query`
  //       mutations (η οθόνη «διαθεσιμότητα υλικών» πιθανόν σώζει μέσω GraphQL).
  const ACTION_RE = /availability|self-activation|\/commands\b|\/catalogs?\/|product-options|\/query\b|\/products?\/[^/]+/i;
  // Telemetry/analytics — ΠΟΤΕ action (αλλιώς spam· το g/collect URL περιέχει «availability»).
  const TRACK_RE = /google-analytics|googletagmanager|\/g\/collect\b|px-cloud\.net|\/collector\b|doubleclick|sentry\.io|datadoghq|analytics\.google/i;
  function isActionUrl(url, method) {
    return method !== 'GET' && !TRACK_RE.test(url || '') && ACTION_RE.test(url || '');
  }

  function post(kind, url, status, body) {
    try {
      if (typeof body !== 'string') return;
      if (body.length > MAX_BODY) body = body.slice(0, MAX_BODY);
      window.postMessage({ source: TAG, kind, url: String(url || ''), status: status || 0, body, ts: Date.now() }, '*');
    } catch (e) {}
  }

  // Στέλνει μια «ενέργεια» (request+response μαζί) για availability endpoints.
  function postAction(url, method, reqBody, status, resBody) {
    try {
      const payload = JSON.stringify({
        method: String(method || '').toUpperCase(),
        reqBody: (typeof reqBody === 'string') ? reqBody.slice(0, MAX_ACT_BODY) : '',
        resBody: (typeof resBody === 'string') ? resBody.slice(0, MAX_ACT_BODY) : '',
      });
      window.postMessage({ source: TAG, kind: 'action', url: String(url || ''), status: status || 0, body: payload, ts: Date.now() }, '*');
    } catch (e) {}
  }

  function isJsonish(ct, text) {
    if (/json/i.test(ct || '')) return true;
    const t = (text || '').trim();
    return t.startsWith('{') || t.startsWith('[');
  }

  // ── fetch ──────────────────────────────────────────────────────────────────
  const _fetch = window.fetch;
  if (typeof _fetch === 'function') {
    window.fetch = function (...args) {
      const req  = args[0];
      const init = args[1] || {};
      const url  = (typeof req === 'string') ? req : (req && req.url) || '';
      const method  = (init.method || (req && req.method) || 'GET').toUpperCase();
      const reqBody = (typeof init.body === 'string') ? init.body : '';
      const isAction = isActionUrl(url, method);
      return _fetch.apply(this, args).then((res) => {
        try {
          const ct = res.headers ? res.headers.get('content-type') : '';
          const clone = res.clone();
          clone.text().then((t) => { if (isJsonish(ct, t)) post('fetch', url, res.status, t); }).catch(() => {});
        } catch (e) {}
        // ΝΕΟ: σύλληψη ενέργειας διαθεσιμότητας (ανεξάρτητα από JSON response)
        if (isAction) {
          try {
            res.clone().text()
              .then((rt) => postAction(url, method, reqBody, res.status, rt || ''))
              .catch(() => postAction(url, method, reqBody, res.status, ''));
          } catch (e) { postAction(url, method, reqBody, res.status, ''); }
        }
        return res;
      });
    };
  }

  // ── XMLHttpRequest ───────────────────────────────────────────────────────────
  const _open = XMLHttpRequest.prototype.open;
  const _send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__tamam_url = url;
    this.__tamam_method = (method || 'GET').toUpperCase();
    return _open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function (data) {
    const reqBody = (typeof data === 'string') ? data : '';
    this.addEventListener('load', function () {
      try {
        const ct = this.getResponseHeader ? this.getResponseHeader('content-type') : '';
        const text = (this.responseType === '' || this.responseType === 'text') ? this.responseText : '';
        if (text && isJsonish(ct, text)) post('xhr', this.__tamam_url || '', this.status, text);
      } catch (e) {}
      // ΝΕΟ: σύλληψη ενέργειας διαθεσιμότητας
      try {
        if (isActionUrl(this.__tamam_url || '', this.__tamam_method)) {
          const resBody = (this.responseType === '' || this.responseType === 'text') ? (this.responseText || '') : '';
          postAction(this.__tamam_url || '', this.__tamam_method, reqBody, this.status, resBody);
        }
      } catch (e) {}
    });
    return _send.apply(this, arguments);
  };
})();
