(function () {
  'use strict';

  // ── Storage keys (τα 2 πρώτα είναι backward-compatible με v1) ──────────────────
  const STORAGE_KEY  = 'modifiers';        // order modifier entries (v1)
  const PRODUCTS_KEY = 'efood_products';   // product name counts (v1)
  const SEEN_KEY     = 'efood_seen_orders';// order keys ήδη μετρημένα (v2 — dedup)
  const RAWORD_KEY   = 'efood_raw_orders'; // raw verbatim order segments (v2)
  const NETWORK_KEY  = 'efood_network';    // captured API responses (v2)
  const CATALOG_KEY  = 'efood_catalog';    // best-effort δομή καταλόγου (v2)
  const ACTIONS_KEY  = 'efood_actions';    // captured availability ACTIONS (request+response) (v2.4)

  const MAX_ENTRIES   = 2000;
  const MAX_SEEN      = 800;
  const MAX_RAW_ORD   = 250;
  const MAX_NET       = 200;
  const MAX_ACT       = 120;
  // Θόρυβος που ΔΕΝ αποθηκεύεται (polling/manifests) — αλλιώς διώχνει τα catalog responses
  const NOISE_RE      = /deliveries-web|\/collector|\/query\b|\/features|version\.json|\/availability|\/contacts|price-suggestions|self-activation|pushNotification|\/commands\b/i;
  const RELEVANT_RE   = /catalog|product|menu|option|modifier|bundle|order|item/i;
  const PANEL_ID      = 'tamam-modifier-inspector-panel';
  const TOGGLE_ID     = 'tamam-modifier-inspector-toggle';
  const STYLE_ID      = 'tamam-modifier-inspector-style';
  const CAPTURE_TAG   = '__TAMAM_EFOOD_CAPTURE__';
  const REFRESH_MS    = 5000;
  const DEBOUNCE_MS   = 600;
  const CONFIRM_MS    = 3000;

  let _debounceTimer = null;
  let _refreshTimer  = null;
  let _clearConfirm  = null;
  let _clearPending  = false;
  let _panelOpen     = false;
  let _activeTab     = 'products'; // 'products' | 'modifiers' | 'network'

  // ── CSS ───────────────────────────────────────────────────────────────────────
  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = `
      #${TOGGLE_ID} {
        position:fixed; bottom:20px; right:20px;
        width:44px; height:44px; background:#f5c842; color:#1a1d26;
        border:none; border-radius:50%; font-size:20px; cursor:pointer;
        z-index:2147483646; display:flex; align-items:center; justify-content:center;
        box-shadow:0 2px 12px rgba(245,200,66,.45); transition:transform .15s;
        line-height:1; padding:0;
      }
      #${TOGGLE_ID}:hover { transform:scale(1.1); }

      #${PANEL_ID} {
        position:fixed; bottom:74px; right:20px; width:400px;
        background:#1a1d26; border:1px solid #2a2d3a; border-radius:12px;
        z-index:2147483645; font-family:'Segoe UI',system-ui,sans-serif;
        font-size:13px; color:#e0e0e0;
        box-shadow:0 8px 32px rgba(0,0,0,.6); overflow:hidden; display:none;
      }
      #${PANEL_ID}.open { display:block; }

      .tmi-header {
        display:flex; align-items:center; justify-content:space-between;
        padding:12px 14px 10px; border-bottom:1px solid #2a2d3a; background:#1e2130;
      }
      .tmi-title { font-weight:700; font-size:13px; color:#f5c842; }
      .tmi-close {
        background:none; border:none; color:#888; font-size:16px;
        cursor:pointer; padding:0 2px; line-height:1;
      }
      .tmi-close:hover { color:#f5c842; }

      .tmi-tabs { display:flex; background:#161820; border-bottom:1px solid #2a2d3a; }
      .tmi-tab {
        flex:1; padding:8px 6px; border:none; background:none;
        color:#666; font-size:12px; font-weight:600; cursor:pointer;
        border-bottom:2px solid transparent; transition:color .15s; font-family:inherit;
      }
      .tmi-tab.active { color:#f5c842; border-bottom-color:#f5c842; }
      .tmi-tab:hover:not(.active) { color:#aaa; }

      .tmi-stats {
        padding:7px 14px; font-size:11.5px; color:#8a8fa8;
        border-bottom:1px solid #2a2d3a; background:#1c1f2d;
      }
      .tmi-stats span { color:#f5c842; font-weight:600; }

      .tmi-list {
        max-height:280px; overflow-y:auto; margin:4px 6px;
        scrollbar-width:thin; scrollbar-color:#2a2d3a transparent;
      }
      .tmi-list::-webkit-scrollbar { width:4px; }
      .tmi-list::-webkit-scrollbar-thumb { background:#2a2d3a; border-radius:2px; }

      .tmi-row {
        display:flex; align-items:center; justify-content:space-between;
        padding:5px 8px; border-radius:6px;
      }
      .tmi-row:hover { background:rgba(245,200,66,.05); }
      .tmi-row-text {
        flex:1; color:#c8cce0; font-size:12.5px;
        white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-right:8px;
      }
      .tmi-row-count {
        font-size:11px; color:#f5c842; font-weight:700;
        background:rgba(245,200,66,.12); padding:1px 6px; border-radius:10px; flex-shrink:0;
      }
      .tmi-row-count.paid { color:#f5a623; background:rgba(245,166,35,.12); }
      .tmi-empty { padding:20px 14px; text-align:center; color:#555a6e; font-style:italic; font-size:12px; }

      .tmi-footer { display:flex; gap:6px; padding:8px 14px 12px; border-top:1px solid #2a2d3a; flex-wrap:wrap; }
      .tmi-btn {
        flex:1; padding:6px 8px; border-radius:7px;
        border:1px solid #2a2d3a; background:#22253a; color:#c8cce0;
        font-size:11px; cursor:pointer; transition:background .15s; white-space:nowrap;
        font-family:inherit; min-width:0;
      }
      .tmi-btn:hover { background:#2a2d3a; color:#f5c842; border-color:rgba(245,200,66,.35); }
      .tmi-btn.copy { color:#5bcc5b; border-color:rgba(91,204,91,.3); }
      .tmi-btn.copy:hover { background:rgba(91,204,91,.1); }
      .tmi-btn.copy.done { color:#f5c842; }
      .tmi-btn.danger { color:#e05a5a; border-color:rgba(224,90,90,.25); }
      .tmi-btn.danger:hover { background:rgba(224,90,90,.1); border-color:rgba(224,90,90,.5); }
      .tmi-btn.warn { color:#f5a623; border-color:rgba(245,166,35,.35); background:rgba(245,166,35,.08); }
    `;
    document.documentElement.appendChild(s);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────────
  function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  function escAttr(s) { return String(s).replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
  function getLS(keys, cb) { try { chrome.storage.local.get(keys, cb); } catch (e) { cb({}); } }
  function setLS(obj, cb)  { try { chrome.storage.local.set(obj, cb); } catch (e) { if (cb) cb(); } }

  // ── Order parsing ───────────────────────────────────────────────────────────────
  function scanOrder() {
    const bodyText = document.body ? document.body.innerText : '';
    if (!bodyText) return;

    const phoneMatch = bodyText.match(/\+30\d{10}/);
    if (!phoneMatch) return;
    const subTotalIdx = bodyText.indexOf('Υποσύνολο', phoneMatch.index);
    if (subTotalIdx === -1) return;

    const segment = bodyText.slice(phoneMatch.index, subTotalIdx);
    const lines    = segment.split('\n').map(l => l.trim()).filter(Boolean);
    const qtyPat   = /^(\d+)\s*[xX×]/;
    const zeroPat  = /^0[,.]00\s*€|0[,.]00$/;
    const paidPat  = /^\+\s*\d+[,.]\d{2}/; // e-food προθέτει "+" στις χρεώσιμες επιλογές

    const foundItems = []; // {itemName, modifiers:[{text,price,isFree}]}
    let cur = null;
    const seenScan = new Set();

    const pushMod = (name, price, isFree) => {
      if (!cur) return;
      const key = `${cur.itemName}|||${name}`;
      if (seenScan.has(key)) return;
      seenScan.add(key);
      cur.modifiers.push({ text: name, price: price || (isFree ? '0,00 €' : ''), isFree: !!isFree });
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (qtyPat.test(line)) {
        const nameOnSameLine = line.replace(qtyPat, '').trim();
        if (nameOnSameLine) {
          // Παλιά μορφή: "2 × Όνομα"
          if (cur) foundItems.push(cur);
          cur = { itemName: nameOnSameLine, modifiers: [] };
        } else {
          // Μορφή efood: "1 x\nΌΝΟΜΑ\nΤΙΜΉ €"
          const nextName  = lines[i + 1] ? lines[i + 1].trim() : '';
          const nextPrice = lines[i + 2] ? lines[i + 2].trim() : '';
          const isZero    = zeroPat.test(nextPrice);
          const isPaidMod = paidPat.test(nextPrice);
          if (nextName && (isZero || isPaidMod) && cur) {
            pushMod(nextName, nextPrice, isZero);
            i += 2;
          } else if (nextName) {
            if (cur) foundItems.push(cur);
            cur = { itemName: nextName, modifiers: [] };
            i += 2;
          }
        }
      } else if (cur) {
        // Fallback παλιάς μορφής: modifier χωρίς qty pattern
        if (zeroPat.test(line)) continue;
        const next = lines[i + 1] ? lines[i + 1].trim() : '';
        if ((zeroPat.test(next) || paidPat.test(next)) && line.length >= 3) {
          pushMod(line, next, zeroPat.test(next));
          i++;
        }
      }
    }
    if (cur) foundItems.push(cur);
    if (!foundItems.length) return;

    // ── Dedup ανά παραγγελία (διορθώνει το φουσκωμένο count) ──
    const orderKey = phoneMatch[0] + '::' + foundItems.map(f => f.itemName).join('|');

    getLS([SEEN_KEY], (r) => {
      const seen = Array.isArray(r[SEEN_KEY]) ? r[SEEN_KEY] : [];
      if (seen.includes(orderKey)) return; // ήδη μετρημένη — μην ξαναμετρήσεις

      const now = new Date().toISOString();
      const url = location.href;

      // Mark order ως seen
      const newSeen = [...seen, orderKey].slice(-MAX_SEEN);
      setLS({ [SEEN_KEY]: newSeen });

      // Raw verbatim segment (ground truth για offline re-parse)
      getLS([RAWORD_KEY], (rr) => {
        const raw = Array.isArray(rr[RAWORD_KEY]) ? rr[RAWORD_KEY] : [];
        raw.push({ orderKey, capturedAt: now, url, rawText: segment });
        setLS({ [RAWORD_KEY]: raw.slice(-MAX_RAW_ORD) });
      });

      // Modifiers (content-deduped)
      const modEntries = foundItems.filter(f => f.modifiers.length > 0)
        .map(f => ({ itemName: f.itemName, modifiers: f.modifiers, capturedAt: now, url }));
      if (modEntries.length) {
        getLS([STORAGE_KEY], (mr) => {
          const existing = Array.isArray(mr[STORAGE_KEY]) ? mr[STORAGE_KEY] : [];
          const makeKey  = e => e.itemName + '|||' + e.modifiers.map(m => m.text).sort().join('|');
          const keys     = new Set(existing.map(makeKey));
          const fresh    = modEntries.filter(e => !keys.has(makeKey(e)));
          if (!fresh.length) return;
          setLS({ [STORAGE_KEY]: [...existing, ...fresh].slice(-MAX_ENTRIES) });
        });
      }

      // Product names — τώρα +1 ΑΝΑ ΠΑΡΑΓΓΕΛΙΑ (όχι ανά scan)
      const names = [...new Set(foundItems.map(f => f.itemName).filter(n => n.length >= 2))];
      if (names.length) {
        getLS([PRODUCTS_KEY], (pr) => {
          const existing = Array.isArray(pr[PRODUCTS_KEY]) ? pr[PRODUCTS_KEY] : [];
          const map = new Map(existing.map(p => [p.name, p]));
          names.forEach(n => {
            if (map.has(n)) { map.get(n).count++; map.get(n).lastSeen = now; }
            else map.set(n, { name: n, count: 1, lastSeen: now });
          });
          const updated = [...map.values()].sort((a, b) => b.count - a.count).slice(0, 400);
          setLS({ [PRODUCTS_KEY]: updated }, () => {
            if (_panelOpen && _activeTab === 'products') renderPanel();
          });
        });
      }
    });
  }

  // ── Network capture (από inject.js) ──────────────────────────────────────────
  // Πλατιά ανίχνευση πεδίων — το e-food schema δεν είναι γνωστό, οπότε δοκιμάζουμε
  // πολλές παραλλαγές ονομάτων. Backstop: το raw JSON αποθηκεύεται ούτως ή άλλως.
  const PRICE_FIELDS = ['price','basePrice','priceCents','amount','cost','value','unitPrice','fromPrice','minPrice','priceText','priceWithTax','finalPrice'];
  const KID_FIELDS   = ['options','choices','modifiers','values','items','children','subItems','optionValues','modifierGroups','groups','attributes'];
  function pickField(o, fields) { for (const f of fields) if (o[f] != null) return o[f]; return null; }
  function pickPrice(o) { return pickField(o, PRICE_FIELDS); }
  function pickKids(o) {
    for (const f of KID_FIELDS) {
      const v = o[f];
      if (Array.isArray(v) && v.length && v.some(c => c && typeof c === 'object' && (c.name || c.title || c.label))) return v;
    }
    return null;
  }
  function pickMin(o) {
    // e-food: nested σε quantity.minimum (όχι top-level) — έλεγξε πρώτα
    if (o.quantity && typeof o.quantity === 'object' && o.quantity.minimum != null) return o.quantity.minimum;
    const v = pickField(o, ['min','minSelect','minChoices','minSelection','minQuantity','minQty','minimum','minAmount','minPermitted','minToSelect','minItems']);
    if (v != null) return v;
    if (o.required === true || o.isRequired === true || o.mandatory === true) return 1;
    if (o.required === false || o.isRequired === false || o.mandatory === false) return 0;
    return null;
  }
  function pickMax(o) {
    // e-food: nested σε quantity.maximum (όχι top-level) — έλεγξε πρώτα
    if (o.quantity && typeof o.quantity === 'object' && o.quantity.maximum != null) return o.quantity.maximum;
    const v = pickField(o, ['max','maxSelect','maxChoices','maxSelection','maxQuantity','maxQty','maximum','maxAmount','maxPermitted','maxToSelect','maxItems']);
    if (v != null) return v;
    if (o.multiple === false || o.multiSelect === false) return 1;
    return null;
  }
  function isDefaultOpt(o) {
    return !!(o.default || o.selected || o.preselected || o.isDefault || o.checked || o.isSelected || o.defaultSelected);
  }
  function looksLikeGroup(o) {
    if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
    const name = o.name || o.title || o.label;
    return typeof name === 'string' && !!name && !!pickKids(o);
  }
  function looksLikeProduct(o) {
    if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
    const name = o.name || o.title;
    if (typeof name !== 'string' || !name) return false;
    if (looksLikeGroup(o)) return false;        // είναι ομάδα, όχι προϊόν
    if (pickPrice(o) != null) return true;      // έχει τιμή → προϊόν
    for (const k in o) { const v = o[k]; if (Array.isArray(v) && v.some(looksLikeGroup)) return true; } // κρατά option-groups
    return false;
  }
  function extractCatalog(json) {
    const products = [], groups = [], seen = new Set();
    // inOptions=true: βρισκόμαστε μέσα στα παιδιά μιας ομάδας → οι επιλογές ΔΕΝ μετράνε ως προϊόντα
    function walk(node, inOptions) {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) { node.forEach(n => walk(n, inOptions)); return; }
      if (looksLikeGroup(node)) {
        const name = node.name || node.title || node.label;
        const kids = pickKids(node);
        const k = 'g:' + name + ':' + kids.length;
        if (!seen.has(k)) {
          seen.add(k);
          groups.push({
            id: node.id ?? null,
            name,
            min: pickMin(node),
            max: pickMax(node),
            options: kids.map(c => ({
              id: c.id ?? null,
              name: c.name || c.title || c.label || '',
              price: pickPrice(c) ?? 0,
              default: isDefaultOpt(c)
            }))
          });
        }
        for (const key in node) { try { walk(node[key], node[key] === kids ? true : inOptions); } catch (e) {} }
        return;
      }
      if (!inOptions && looksLikeProduct(node)) {
        const name = String(node.name || node.title || '').trim();
        const price = pickPrice(node);
        const priceOk = price == null || typeof price === 'number' || /^[\d.,]/.test(String(price));
        if (name.length >= 2 && !/^(price|τιμή|name|όνομα|currency)$/i.test(name) && priceOk) {
          const k = 'p:' + name + ':' + (node.id ?? '');
          if (!seen.has(k)) { seen.add(k); products.push({ id: node.id ?? null, name, price }); }
        }
      }
      for (const key in node) { try { walk(node[key], inOptions); } catch (e) {} }
    }
    try { walk(json, false); } catch (e) {}
    return { products, groups };
  }
  function mergeCatalog(existing, fresh) {
    const out = { products: [...(existing.products || [])], groups: [...(existing.groups || [])] };
    const pSeen = new Set(out.products.map(p => p.name));
    fresh.products.forEach(p => { if (p.name && !pSeen.has(p.name)) { pSeen.add(p.name); out.products.push(p); } });
    // richness: # options με τιμή + αν έχει min/max — προτίμα την πλουσιότερη εκδοχή
    const richness = g => (g.options || []).reduce((s, o) => s + (o.price > 0 ? 1 : 0), 0)
                          + (g.min != null ? 1 : 0) + (g.max != null ? 1 : 0);
    const gIdx = new Map(out.groups.map((g, i) => [g.name + ':' + g.options.length, i]));
    fresh.groups.forEach(g => {
      const k = g.name + ':' + g.options.length;
      if (!gIdx.has(k)) { gIdx.set(k, out.groups.length); out.groups.push(g); }
      else { const i = gIdx.get(k); if (richness(g) > richness(out.groups[i])) out.groups[i] = g; } // upgrade: η product-options εκδοχή (με τιμές/min-max) νικά τη φτωχή
    });
    return out;
  }

  // ── Action capture (availability toggle) — request+response για replay ────────
  function handleActionCapture(d) {
    let parsed = {};
    try { parsed = JSON.parse(d.body || '{}'); } catch (e) {}
    let path = d.url; try { path = new URL(d.url).pathname; } catch (e) {}
    getLS([ACTIONS_KEY], (r) => {
      let acts = Array.isArray(r[ACTIONS_KEY]) ? r[ACTIONS_KEY] : [];
      acts.push({
        url: d.url, path, status: d.status, ts: d.ts,
        method:  parsed.method  || '',
        reqBody: parsed.reqBody || '',
        resBody: parsed.resBody || '',
      });
      setLS({ [ACTIONS_KEY]: acts.slice(-MAX_ACT) }, () => {
        if (_panelOpen && _activeTab === 'network') renderPanel();
      });
    });
    // Οπτική επιβεβαίωση (ο ιδιοκτήτης βλέπει ότι η σύλληψη έπιασε)
    flashActionCapture(parsed.method || '?', path);
  }

  // Μικρό διακριτικό banner που δείχνει ότι συνελήφθη ενέργεια διαθεσιμότητας.
  function flashActionCapture(method, path) {
    try {
      let el = document.getElementById('tmi-action-flash');
      if (!el) {
        el = document.createElement('div');
        el.id = 'tmi-action-flash';
        el.style.cssText = 'position:fixed;bottom:16px;left:16px;z-index:2147483647;' +
          'background:#0f2e1a;color:#8ef5b0;border:1px solid #38d97a;border-radius:8px;' +
          'padding:10px 14px;font:600 13px/1.4 system-ui,sans-serif;max-width:70vw;' +
          'box-shadow:0 6px 20px rgba(0,0,0,.5);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
        document.body.appendChild(el);
      }
      el.textContent = '✅ Συνελήφθη ενέργεια: ' + method + ' ' + path;
      el.style.display = 'block';
      clearTimeout(el.__tmr);
      el.__tmr = setTimeout(() => { el.style.display = 'none'; }, 4000);
    } catch (e) {}
  }

  function handleNetworkCapture(d) {
    // Ενέργειες διαθεσιμότητας → ξεχωριστός κάδος (χωρίς noise-filter/JSON απαίτηση)
    if (d.kind === 'action') { handleActionCapture(d); return; }
    const url = d.url || '';
    if ((d.body || '').length < 50) return;                       // skip κενά/μικρά
    if (NOISE_RE.test(url) && !RELEVANT_RE.test(url)) return;     // skip θόρυβο πριν το parse
    let json;
    try { json = JSON.parse(d.body); } catch (e) { return; }
    const cat = extractCatalog(json);
    if (!RELEVANT_RE.test(url) && !cat.products.length && !cat.groups.length) return; // κράτα μόνο σχετικά

    getLS([NETWORK_KEY, CATALOG_KEY], (r) => {
      let net = Array.isArray(r[NETWORK_KEY]) ? r[NETWORK_KEY] : [];
      let path = url; try { path = new URL(url).pathname; } catch (e) {}
      const entry = {
        url, path, kind: d.kind, status: d.status, ts: d.ts,
        bytes: (d.body || '').length,
        products: cat.products.length, groups: cat.groups.length,
        body: d.body
      };
      // Dedup ΑΝΑ URL (κράτα το νεότερο) → re-fetches δεν γεμίζουν το buffer
      net = net.filter(e => (e.path || e.url) !== path);
      net.push(entry);
      const out = { [NETWORK_KEY]: net.slice(-MAX_NET) };
      if (cat.products.length || cat.groups.length) {
        out[CATALOG_KEY] = mergeCatalog(r[CATALOG_KEY] || { products: [], groups: [] }, cat);
      }
      setLS(out, () => { if (_panelOpen && _activeTab === 'network') renderPanel(); });
    });
  }

  // ── Panel ─────────────────────────────────────────────────────────────────────
  function injectPanel() {
    if (document.getElementById(PANEL_ID)) return;
    const p = document.createElement('div');
    p.id = PANEL_ID;
    p.innerHTML = `
      <div class="tmi-header">
        <span class="tmi-title">🔬 TAMAM Inspector v2.4</span>
        <button class="tmi-close" id="tmi-close-btn">✕</button>
      </div>
      <div class="tmi-tabs">
        <button class="tmi-tab active" id="tmi-tab-products" data-tab="products">📦 Προϊόντα</button>
        <button class="tmi-tab" id="tmi-tab-modifiers" data-tab="modifiers">🔧 Modifiers</button>
        <button class="tmi-tab" id="tmi-tab-network" data-tab="network">🌐 Catalog</button>
      </div>
      <div class="tmi-stats" id="tmi-stats"></div>
      <div class="tmi-list" id="tmi-list"></div>
      <div class="tmi-footer" id="tmi-footer"></div>
    `;
    document.documentElement.appendChild(p);
    document.getElementById('tmi-close-btn').addEventListener('click', closePanel);
    document.getElementById('tmi-tab-products').addEventListener('click', () => switchTab('products'));
    document.getElementById('tmi-tab-modifiers').addEventListener('click', () => switchTab('modifiers'));
    document.getElementById('tmi-tab-network').addEventListener('click', () => switchTab('network'));
  }

  function switchTab(tab) {
    _activeTab = tab;
    ['products', 'modifiers', 'network'].forEach(t =>
      document.getElementById('tmi-tab-' + t)?.classList.toggle('active', t === tab));
    resetClear();
    renderPanel();
  }

  function renderPanel() {
    if (_activeTab === 'products') renderProducts();
    else if (_activeTab === 'modifiers') renderModifiers();
    else renderNetwork();
  }

  function renderProducts() {
    getLS([PRODUCTS_KEY], (r) => {
      const items = Array.isArray(r[PRODUCTS_KEY]) ? r[PRODUCTS_KEY] : [];
      const stats = document.getElementById('tmi-stats');
      const list = document.getElementById('tmi-list');
      const footer = document.getElementById('tmi-footer');
      if (!stats || !list || !footer) return;

      stats.innerHTML = `Μοναδικά προϊόντα: <span>${items.length}</span> &nbsp;|&nbsp; count = παραγγελίες`;
      list.innerHTML = items.length
        ? items.map(p => `
            <div class="tmi-row">
              <span class="tmi-row-text" title="${escAttr(p.name)}">${escHtml(p.name)}</span>
              <span class="tmi-row-count">× ${p.count}</span>
            </div>`).join('')
        : '<div class="tmi-empty">Δεν έχουν καταγραφεί προϊόντα ακόμα.<br>Άφησε παραγγελίες να έρθουν.</div>';

      footer.innerHTML = `
        <button class="tmi-btn copy" id="tmi-copy-btn">📋 Αντιγραφή</button>
        <button class="tmi-btn" id="tmi-download-btn">⬇ JSON</button>
        <button class="tmi-btn danger" id="tmi-clear-btn">🗑 Καθαρισμός</button>
      `;
      document.getElementById('tmi-copy-btn').addEventListener('click', copyProducts);
      document.getElementById('tmi-download-btn').addEventListener('click', downloadJSON);
      document.getElementById('tmi-clear-btn').addEventListener('click', handleClear);
    });
  }

  function renderModifiers() {
    getLS([STORAGE_KEY], (r) => {
      const entries = Array.isArray(r[STORAGE_KEY]) ? r[STORAGE_KEY] : [];
      const modMap = new Map();
      for (const e of entries)
        for (const m of (e.modifiers || [])) {
          if (!modMap.has(m.text)) modMap.set(m.text, { count: 0, seenWith: new Set(), paid: false });
          const d = modMap.get(m.text);
          d.count++; d.seenWith.add(e.itemName);
          if (m.isFree === false) d.paid = true;
        }
      const sorted = [...modMap.entries()].sort((a, b) => b[1].count - a[1].count);

      const stats = document.getElementById('tmi-stats');
      const list = document.getElementById('tmi-list');
      const footer = document.getElementById('tmi-footer');
      if (!stats || !list || !footer) return;

      stats.innerHTML = `Καταγραφές: <span>${entries.length}</span> &nbsp;|&nbsp; Μοναδικά: <span>${sorted.length}</span>`;
      list.innerHTML = sorted.length
        ? sorted.map(([text, d]) => `
            <div class="tmi-row" title="Εμφανίζεται με: ${escAttr([...d.seenWith].join(', '))}">
              <span class="tmi-row-text">${d.paid ? '💰 ' : ''}${escHtml(text)}</span>
              <span class="tmi-row-count ${d.paid ? 'paid' : ''}">× ${d.count}</span>
            </div>`).join('')
        : '<div class="tmi-empty">Δεν έχουν καταγραφεί modifiers ακόμα.</div>';

      footer.innerHTML = `
        <button class="tmi-btn" id="tmi-download-btn">⬇ JSON</button>
        <button class="tmi-btn danger" id="tmi-clear-btn">🗑 Καθαρισμός</button>
      `;
      document.getElementById('tmi-download-btn').addEventListener('click', downloadJSON);
      document.getElementById('tmi-clear-btn').addEventListener('click', handleClear);
    });
  }

  function renderNetwork() {
    getLS([NETWORK_KEY, CATALOG_KEY], (r) => {
      const net = Array.isArray(r[NETWORK_KEY]) ? r[NETWORK_KEY] : [];
      const cat = r[CATALOG_KEY] || { products: [], groups: [] };
      const stats = document.getElementById('tmi-stats');
      const list = document.getElementById('tmi-list');
      const footer = document.getElementById('tmi-footer');
      if (!stats || !list || !footer) return;

      stats.innerHTML = `API responses: <span>${net.length}</span> &nbsp;|&nbsp; Catalog: <span>${cat.products.length}</span> προϊ. / <span>${cat.groups.length}</span> ομάδες`;

      const groupRows = cat.groups.slice(0, 60).map(g => `
        <div class="tmi-row" title="${escAttr(g.options.map(o => o.name + (o.default ? ' ✓' : '')).join(', '))}">
          <span class="tmi-row-text">🔧 ${escHtml(g.name)} <span style="opacity:.5">(${g.options.length})</span></span>
          <span class="tmi-row-count">${(g.min != null || g.max != null) ? `${g.min ?? 0}–${g.max ?? '∞'}` : '—'}</span>
        </div>`).join('');
      const netRows = net.slice().reverse().slice(0, 40).map(e => {
        let path = e.url; try { path = new URL(e.url).pathname; } catch (x) {}
        const tag = (e.products || e.groups) ? `${e.products}p/${e.groups}g` : `${(e.bytes / 1024).toFixed(0)}kB`;
        return `
        <div class="tmi-row" title="${escAttr(e.url)}">
          <span class="tmi-row-text">${escHtml(path)}</span>
          <span class="tmi-row-count">${tag}</span>
        </div>`;
      }).join('');

      const body = (groupRows || netRows)
        ? (groupRows + (groupRows && netRows ? '<div style="border-top:1px solid #2a2d3a;margin:6px 2px"></div>' : '') + netRows)
        : '<div class="tmi-empty">Καμία καταγραφή δικτύου ακόμα.<br>Μπες στη <b>Διαχείριση Μενού</b> του e-food<br>και περιηγήσου στα προϊόντα.</div>';
      list.innerHTML = body;

      footer.innerHTML = `
        <button class="tmi-btn copy" id="tmi-download-cat-btn">⬇ Catalog JSON</button>
        <button class="tmi-btn" id="tmi-download-btn">⬇ Πλήρες</button>
        <button class="tmi-btn danger" id="tmi-clear-btn">🗑 Καθαρισμός</button>
      `;
      document.getElementById('tmi-download-cat-btn').addEventListener('click', downloadCatalog);
      document.getElementById('tmi-download-btn').addEventListener('click', downloadJSON);
      document.getElementById('tmi-clear-btn').addEventListener('click', handleClear);
    });
  }

  // ── Copy / Download ─────────────────────────────────────────────────────────────
  function copyProducts() {
    getLS([PRODUCTS_KEY], (r) => {
      const items = Array.isArray(r[PRODUCTS_KEY]) ? r[PRODUCTS_KEY] : [];
      navigator.clipboard.writeText(JSON.stringify(items.map(p => p.name), null, 2)).then(() => {
        const btn = document.getElementById('tmi-copy-btn');
        if (btn) {
          btn.textContent = '✓ Αντιγράφηκε!'; btn.classList.add('done');
          setTimeout(() => { btn.textContent = '📋 Αντιγραφή'; btn.classList.remove('done'); }, 2000);
        }
      }).catch(() => alert('Αντιγραφή απέτυχε — δοκίμασε ξανά'));
    });
  }

  function _blobDownload(obj, prefix) {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const now = new Date(), pad = n => String(n).padStart(2, '0');
    const a = document.createElement('a');
    a.href = url;
    a.download = `${prefix}-${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}T${pad(now.getHours())}-${pad(now.getMinutes())}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function downloadCatalog() {
    getLS([CATALOG_KEY, NETWORK_KEY, ACTIONS_KEY], (r) => {
      _blobDownload({
        exportedAt: new Date().toISOString(),
        catalog: r[CATALOG_KEY] || { products: [], groups: [] },
        rawNetwork: Array.isArray(r[NETWORK_KEY]) ? r[NETWORK_KEY] : [],
        availabilityActions: Array.isArray(r[ACTIONS_KEY]) ? r[ACTIONS_KEY] : []
      }, 'efood-catalog');
    });
  }

  function downloadJSON() {
    getLS([STORAGE_KEY, PRODUCTS_KEY, RAWORD_KEY, NETWORK_KEY, CATALOG_KEY, ACTIONS_KEY], (r) => {
      const entries = Array.isArray(r[STORAGE_KEY]) ? r[STORAGE_KEY] : [];
      const modMap = new Map();
      for (const e of entries)
        for (const m of (e.modifiers || [])) {
          if (!modMap.has(m.text)) modMap.set(m.text, { count: 0, seenWith: new Set(), paid: false });
          const d = modMap.get(m.text);
          d.count++; d.seenWith.add(e.itemName);
          if (m.isFree === false) d.paid = true;
        }
      _blobDownload({
        exportedAt: new Date().toISOString(),
        version: 2,
        products: Array.isArray(r[PRODUCTS_KEY]) ? r[PRODUCTS_KEY] : [],
        uniqueModifiers: [...modMap.entries()].sort((a, b) => b[1].count - a[1].count)
          .map(([text, d]) => ({ text, count: d.count, paid: d.paid, seenWith: [...d.seenWith] })),
        catalog: r[CATALOG_KEY] || { products: [], groups: [] },
        rawModifierEntries: entries,
        rawOrders: Array.isArray(r[RAWORD_KEY]) ? r[RAWORD_KEY] : [],
        rawNetwork: Array.isArray(r[NETWORK_KEY]) ? r[NETWORK_KEY] : [],
        availabilityActions: Array.isArray(r[ACTIONS_KEY]) ? r[ACTIONS_KEY] : []
      }, 'efood-inspector');
    });
  }

  // ── Clear ─────────────────────────────────────────────────────────────────────
  function handleClear() {
    const btn = document.getElementById('tmi-clear-btn');
    if (!btn) return;
    if (!_clearPending) {
      _clearPending = true;
      btn.textContent = '⚠ Σίγουρα;';
      btn.classList.replace('danger', 'warn');
      _clearConfirm = setTimeout(resetClear, CONFIRM_MS);
    } else {
      resetClear();
      const keys = _activeTab === 'products' ? [PRODUCTS_KEY, SEEN_KEY, RAWORD_KEY]
                 : _activeTab === 'modifiers' ? [STORAGE_KEY]
                 : [NETWORK_KEY, CATALOG_KEY, ACTIONS_KEY];
      try { chrome.storage.local.remove(keys, renderPanel); } catch (e) { renderPanel(); }
    }
  }
  function resetClear() {
    _clearPending = false;
    if (_clearConfirm) { clearTimeout(_clearConfirm); _clearConfirm = null; }
    const btn = document.getElementById('tmi-clear-btn');
    if (btn) { btn.textContent = '🗑 Καθαρισμός'; btn.classList.replace('warn', 'danger'); }
  }

  // ── Open/Close ────────────────────────────────────────────────────────────────
  function openPanel() {
    _panelOpen = true;
    document.getElementById(PANEL_ID)?.classList.add('open');
    renderPanel();
    _refreshTimer = setInterval(renderPanel, REFRESH_MS);
  }
  function closePanel() {
    _panelOpen = false;
    document.getElementById(PANEL_ID)?.classList.remove('open');
    if (_refreshTimer) { clearInterval(_refreshTimer); _refreshTimer = null; }
    resetClear();
  }

  function injectToggle() {
    if (document.getElementById(TOGGLE_ID)) return;
    const btn = document.createElement('button');
    btn.id = TOGGLE_ID;
    btn.title = 'TAMAM Inspector';
    btn.textContent = '📊';
    btn.addEventListener('click', () => _panelOpen ? closePanel() : openPanel());
    document.documentElement.appendChild(btn);
  }

  // ── Observer ──────────────────────────────────────────────────────────────────
  function setupObserver() {
    new MutationObserver(() => {
      clearTimeout(_debounceTimer);
      _debounceTimer = setTimeout(scanOrder, DEBOUNCE_MS);
    }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  }

  function setupNetworkBridge() {
    window.addEventListener('message', (e) => {
      if (e.source !== window) return;
      const d = e.data;
      if (!d || d.source !== CAPTURE_TAG) return;
      handleNetworkCapture(d);
    });
  }

  // ── Init ──────────────────────────────────────────────────────────────────────
  function init() {
    injectStyles();
    injectPanel();
    injectToggle();
    setupObserver();
    setupNetworkBridge();
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanOrder);
    else scanOrder();
  }

  if (document.documentElement) init();
  else document.addEventListener('DOMContentLoaded', init);
})();
